# pacote_processamento_imagem

O processamento da imagem do pacote pode ser usado para:
	
	Em processamento:
		- Correspondencia de histograma
		- Semelhanca estrutural
		- Redimensionar imagem
	
	Util:
		- Ler imagem
		- Salvar imagem
		- Plotar imagem
		- Resultado da trama
		- Plotar histograma

## Instalacao

```bash
pip install pacoteprocessamentoimagem
```

## Autor
Isabela Rossetti

## Licenca
[MIT](https://github.com/isabela-rossetti/pacote_imagem_python/blob/main/LICENSE.txt)

